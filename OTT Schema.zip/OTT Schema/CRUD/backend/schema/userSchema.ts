import mongoose, { Schema } from "mongoose"

export const UserSchema: Schema = new mongoose.Schema({
    id: {
        type: Number,
        validate: {
            validator: (v:number) => {
                return v>=1000
            }
        }
    },
    username: {
        type: String,
        required: [true, "Username is required field !"],
        validate: {
            validator: (v: string) => {
                return (/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}/.test(v) == false || String(v).length < 4 || String(v).length > 10 ? false : true)
            }
        }
    },
    password: {
        type: String,
        required:[true,"Password is required field"],
        validate: {
            validator: (v: string) => {
                return (/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}[@,#,$,%,!,^,&,*]{1,}/.test(v) == false || String(v).length < 4 || String(v).length > 10 ? false : true)
            }
        }
    },
    role: {
        type: String, required: [true, "Role is required !"],
        enum: {
            values: ["Admin", "User"],
            message: "Invalid Role Identity"
        }
    },
    createdBy: {
        type: Number,
        validate: {
            validator: (v:number) => {
                return v>=1000
            }
        }
    },
    modifiedBy: {
        type: Number,
        validate: {
            validator: (v:number) => {
                return v>=1000
            }
        }
    }
},
    {
        timestamps: true
    }
)

export const UserModel = mongoose.model("LogInData",UserSchema)
