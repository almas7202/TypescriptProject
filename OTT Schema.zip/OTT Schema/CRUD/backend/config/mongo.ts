import mongoose, { Schema } from "mongoose";
import 'dotenv/config'

mongoose.connect(String(process.env.MONGO))
    .then(() => console.log("Database Connected"))
    .catch((err) => console.log(err))
