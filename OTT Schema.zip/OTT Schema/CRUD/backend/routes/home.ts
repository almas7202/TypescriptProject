import express  from "express"
import { isAuthenticate } from "../middlewares/authenticate"
import { isAuthorise } from "../middlewares/authorise"
import { getHomepage } from "../controllers/userControllers"

export const HomeRouter = express.Router()

HomeRouter.route("/").get(isAuthenticate,getHomepage)