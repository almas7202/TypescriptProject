import express  from "express"
import { findUser, setToken } from "../controllers/userControllers"

export const LogInRouter = express.Router()

LogInRouter.route("/").post(findUser,setToken)