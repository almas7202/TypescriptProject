import express  from "express"
import { registerUser } from "../controllers/userControllers"
import { isAuthenticate } from "../middlewares/authenticate"
import { isAuthorise } from "../middlewares/authorise"

export const RegisterRouter = express.Router()

RegisterRouter.route("/").post(isAuthenticate,isAuthorise,registerUser)