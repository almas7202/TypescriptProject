import express from "express";
import 'dotenv/config'
import { LogInRouter } from "./routes/login";
import { UserModel } from "./config/mongo";
import { RegisterRouter } from "./routes/register";
import { HomeRouter } from "./routes/home";
import cookieParser from 'cookie-parser'

const app = express()

app.listen(process.env.PORT)
app.use(express.json())
app.use(cookieParser())

app.use("/register",RegisterRouter)
app.use("/login",LogInRouter)
app.use("/home",HomeRouter)

UserModel