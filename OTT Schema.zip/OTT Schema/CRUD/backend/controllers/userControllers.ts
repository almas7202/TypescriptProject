import { NextFunction, Request, Response } from "express";
import { UserModel } from "../schema/userSchema";
import Cryptr from "cryptr";
import 'dotenv/config'
import jwt from 'jsonwebtoken';

export const cryptr = new Cryptr(String(process.env.PRIVATE_KEY))

export const registerUser = (req: Request, res: Response) => {
    UserModel.find().then((value: Array<object>) => {
        UserModel.insertMany([
            {
                id: value.length + 1000,
                username: req.body.username,
                password: req.body.password,
                role: req.body.role,
                createdBy: value.length + 1000,
                modifiedBy: value.length + 1000
            }
        ])
            .then(() => res.status(201).send("User Registered Successfully !"))
            .catch((err) => res.status(406).send("Something went wrong !" + err))
    })
        .catch((err) => res.send(err))
}

export const findUser = (req: Request, res: Response, next: NextFunction) => {
    UserModel.findOne({ username: req.body.username })
        .then((value: any) => {
            if (value != null) {
                req.body = value
                next()
            }
            else{
                res.status(401).send("Username doesn't exists")
            }
        })
        .catch((err) => res.status(401).send(err))
}

export const setToken = (req: Request, res: Response, next: NextFunction) => {
    try {
        const foundUser = req.body
        if (foundUser.password == req.body.password) {
            const token = jwt.sign(cryptr.encrypt(JSON.stringify({
                id: foundUser.id,
                username: foundUser.username,
                role: foundUser.role
            })),
                String(process.env.SECRET_KEY),
                { algorithm: 'HS256' }
            )
            res.cookie("AccessToken", token).status(202).send("User Logged In Successfully !")
        }
        else {
            res.status(401).send("Username and Password doesn't match !")
        }
    }
    catch {
        res.status(401).send("Username and Password doesn't match !")
    }
}

export const getHomepage = (req:Request,res:Response)=>{
    res.status(200).send("Welcome to Home Page !")
}