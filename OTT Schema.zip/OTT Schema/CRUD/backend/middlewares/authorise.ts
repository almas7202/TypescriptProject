import { NextFunction, Request, Response } from "express";

export const isAuthorise = (req:Request,res:Response,next:NextFunction)=>{
    try{
        if(req.body["LoggedInUserRole"]=="Admin"){
            res.status(200)
            next()
        }
        else{
            res.status(401).send("Unauthorized User !")
        }
    }
    catch{
        res.status(401).send("Something went wrong !")
    }
}   