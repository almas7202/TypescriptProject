export interface userType{
    id:number,
    username:string,
    password:string,
    role: roles,
    createdBy:number,
    modifiedBy:number,
}

export interface userInfo{
    id:number,
    username:string,
    role: roles,
    createdBy:number,
    modifiedBy:number,
}

enum roles{
    Admin = 1,
    User = 2
}