import mongoose, { Schema } from "mongoose";
import 'dotenv/config'
import { UserModel } from "../schema/userSchema";

export const connectMongoose = ()=>{
    mongoose.connect(String(process.env.MONGO))
        .then(() => console.log("Database Connected"))
        .catch((err) => console.log(err))
    UserModel
}
