import express from "express";
import 'dotenv/config'
import { LogInRouter } from "./routes/login";
import { RegisterRouter } from "./routes/register";
import { HomeRouter } from "./routes/home";
import cookieParser from 'cookie-parser'
import { connectMongoose } from "./config/mongo";
import { transferData } from "./controllers/mysqlControllers";
import { LogOutRouter } from "./routes/logout";

const app = express()

app.listen(process.env.PORT)
app.use(express.json())
app.use(cookieParser())

app.use("/register",RegisterRouter)
app.use("/login",LogInRouter)
app.use("/home",HomeRouter)
app.use("/logout",LogOutRouter)

connectMongoose()