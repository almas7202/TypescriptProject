import { NextFunction, Request, Response } from "express"
import { UserModel } from "../schema/userSchema"

export const logout = (req:Request,res:Response,next:NextFunction)=>{
    UserModel.deleteMany({})
    res.clearCookie("AccessToken").send("User Succesfully Logged Out !")
}