import { UserModel } from "../schema/userSchema";
import { userData } from "../types/userType";
import { connection } from '../config/mysql'
import { NextFunction, Request, Response } from "express";

export const transferData = (req: Request, res: Response, next: NextFunction) => {
    UserModel.find()
        .then((value: any[]) => {
            value.map(
                (user: userData, index: number) => {
                    connection.query("select * from users", (err, result, fields) => {
                        if (!err) {
                            const sqlData: any[] = result
                            const foundIndex = sqlData.findIndex((obj) => (obj.id == user.id))
                            if (foundIndex == -1) {
                                (async () => {
                                    connection.query(
                                        `insert into users values (${user.id},"${user.username}","${user.password}","${user.role}","${user.createdAt}",${user.createdBy},"${user.updatedAt}",${user.modifiedBy});`
                                    );
                                    await UserModel.findOneAndDelete({ id: user.id })
                                })()
                            }
                            else {
                                (async () => {
                                    connection.query(
                                        `update users set username = "${user.username}" , password = "${user.password}" , role = "${user.role}" where id = ${user.id}`
                                    );
                                    await UserModel.findOneAndDelete({ id: user.id })
                                })()
                            }
                        }
                    })
                })
            next()
        }
        )
        .catch((err) => res.send(err))
}

export const getData = (req: Request, res: Response, next: NextFunction) => {
    connection.query("select * from users", async (err, result, fields) => {
        await UserModel.insertMany(result)
        next()
    })
}