import express  from "express"
import { isAuthenticate } from "../middlewares/authenticate"
import { getHomepage } from "../controllers/userControllers"

export const HomeRouter = express.Router()

HomeRouter.route("/").get(isAuthenticate,getHomepage)