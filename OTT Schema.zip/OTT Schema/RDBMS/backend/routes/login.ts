import express  from "express"
import { findUser, setToken } from "../controllers/userControllers"
import { getData } from "../controllers/mysqlControllers"

export const LogInRouter = express.Router()

LogInRouter.route("/").post(getData,findUser,setToken)