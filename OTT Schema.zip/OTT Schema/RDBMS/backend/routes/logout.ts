import express  from "express"
import { findUser, setToken } from "../controllers/userControllers"
import { logout } from "../controllers/logoutControllers"
import { transferData } from "../controllers/mysqlControllers"

export const LogOutRouter = express.Router()

LogOutRouter.route("/").get(transferData,logout)