import { NextFunction, Request, Response } from "express";
import jwt from 'jsonwebtoken'
import { cryptr } from "../controllers/userControllers";
import { UserModel } from "../schema/userSchema";
import {userInfo} from '../types/userType'

export const isAuthenticate = (req:Request,res:Response,next:NextFunction)=>{
    try{
        const payload:string = String(jwt.decode(req.cookies["AccessToken"]))
        const details:userInfo = JSON.parse(cryptr.decrypt(payload))
        UserModel.findOne({id:details["id"],username:details["username"]})
            .then(()=>{
                req.body["LoggedInUserRole"]=details["role"]
                next()
            })
            .catch(()=>{
                res.status(401).send("Unauthenticated User !")
            })
    }
    catch{
        res.status(401).send("Unauthenticated User !")       
    }
}   
