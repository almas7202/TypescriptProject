import express, { Request, Response, Router } from 'express'
import cookieParser from 'cookie-parser'
import { authenticate } from '../utils/auth'
import { AdminRouter } from './admin'


export const HomeRouter = express.Router()
HomeRouter.use(cookieParser())

HomeRouter.route("/").get((req: Request, res: Response) => {
    authenticate(req.cookies["AccessToken"])
        .then((value: Boolean) => {
            {
                value ?
                    res.status(200).send("Welcome To Home Page") :
                    res.status(401).send("Unauthenticated User")
            }
        })
        .catch((err)=>res.status(401).send("Unauthenticated User"))
})

HomeRouter.use("/admin",AdminRouter)
