import express, { Request, Response, Router } from 'express'
import cookieParser from 'cookie-parser'
import { authenticate } from '../utils/auth'
import { UserModel } from '../config/mongo'
import { authorize } from '../utils/autho'

export const AdminRouter = express.Router()
AdminRouter.use(cookieParser())

AdminRouter.route("/").get((req: Request, res: Response) => {
    authorize(req.cookies["AccessToken"])
        .then((value: Boolean) => {
            UserModel.find().then((val: any) => {
                value ?
                    res.status(200).send("Welcome To Admin Page\n" + val) :
                    res.status(401).send("Unauthenticated User")
            }
            )
        })
        .catch((err) => res.status(401).send(err))
})

AdminRouter.route("/").post((req: Request, res: Response) => {
    authorize(req.cookies["AccessToken"])
        .then((value: Boolean) => {
            if (value) {
                UserModel.find().then((value: Array<any>) => {
                    UserModel.insertMany({
                        id: value.length + 1000,
                        name: req.body.name,
                        username: req.body.username,
                        password: req.body.password,
                        age: req.body.age,
                        role: req.body.role,
                        createdBy: value.length + 1000
                    })
                        .then(() => res.send("Successfully User added !"))
                        .catch((err) => res.send(err.errors))
                })
            }
            else {
                res.status(401).send("Unauthorised User Found !")
            }
        })
        .catch((err) => res.status(401).send(err))
})

