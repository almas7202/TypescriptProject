import express, { Request, Response ,Router} from 'express'
import { UserType } from '../main'
import { UserModel } from '../config/mongo'
import jwt from 'jsonwebtoken'
import Cryptr from 'cryptr'

export const LogInRouter = express.Router()

export interface LogInInfo{
    username:string,
    password:string
}
export const cryptr = new Cryptr(String(process.env.PRIVATE_KEY))

LogInRouter.route("/").post((req:Request,res:Response)=>{
    UserModel
    const UserInfo:LogInInfo = {
        username:req.body["username"],
        password:req.body["password"]
    }
    UserModel.findOne({username:UserInfo["username"]}).then((value:any)=>{
        const foundUser:UserType = value
        if(value["password"]==UserInfo.password){
            const token = jwt.sign(
                cryptr.encrypt(JSON.stringify({
                    id:foundUser.id,
                    name:foundUser.name,
                    username:foundUser.username,
                    role:foundUser.role
                })),
                String(process.env.KEY),
                {algorithm:'HS256'}                
            )           
            res.cookie("AccessToken",token).status(200).send("Logged In Sucessfully")
        }
    })
    .catch((err)=>{
        res.status(401).send("Usrname or Password not found")
    })
})