import jwt from 'jsonwebtoken'
import { cryptr } from '../Routes/login'
import { UserType } from '../main'
import { UserModel } from '../config/mongo'

export const authenticate = async (token:string)=>{
    const payload = jwt.decode(token)
    if(payload==null){
        return false
    }
    const UserData:UserType = await JSON.parse(cryptr.decrypt(String(payload)))
    let AuthFlag:Boolean = false;
    await UserModel.findOne({id:UserData["id"]}).then((value:any)=>{
        if(value["username"]==UserData["username"]){
            AuthFlag=true
        }
        else{
            AuthFlag=false
        }
    })
    return AuthFlag
}