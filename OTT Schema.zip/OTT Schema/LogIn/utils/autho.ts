import jwt from 'jsonwebtoken'
import { cryptr } from '../Routes/login'
import { UserType } from '../main'
import { authenticate } from './auth'

export const authorize = async (token: string) => {
    const AuthFlag: Boolean = await authenticate(token).then((value: Boolean) => { return value })
    let AuthoFlag:Boolean = false
    if (AuthFlag) {
        const payload = jwt.decode(token)
        if (payload == null) {
            return false
        }
        const UserData: UserType = await JSON.parse(cryptr.decrypt(String(payload)))
        if (UserData.role == "Admin") {
            AuthoFlag = true           
        }
        else {
            AuthoFlag = false
        }
    }
    return AuthoFlag
}