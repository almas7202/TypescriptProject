import mongoose, { Schema } from 'mongoose'

mongoose.connect("mongodb://localhost:27017/OTT")
        .then(() => console.log("Database Connected"))
        .catch((err: Error) => console.log(err))
    
    const Ottschema: Schema = new mongoose.Schema({
        id: {
            type: Number, validate: {
                validator: function (v: string) {
                    return (String(v).length == 4 ? true : false)
                },
                message: "Id must be of 4 digits"
            }
        },
        name: {
            type: String, required: [true, "Name is required !"], validate: {
                validator: function (v: string) {
                    return (String(v).length < 4 || String(v).length > 10 || /[ ]/g.test(v) == true || /[0-9]/g.test(v) == true ? false : true)
                },
                message: "Name is not valid , Name should be minimum 4 and maximum 10 characters long and It should not contain any digit or whitespace"
            }
        },
        username: {
            type: String, required: [true, "Username is required !"], validate: {
                validator: function (v: string) {
                    return (/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}/.test(v) == false || String(v).length < 4 || String(v).length > 10 ? false : true)
                },
                message: "Username is not valid , Username should be minimum 4 and maximum 10 characters long and It should contain minimum 1 number and minimum 1 capital character"
            }
        },
        password: {
            type: String, required: [true, "Password is required !"], validate: {
                validator: function (v: string) {
                    return (/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}[@,#,$,%,!,^,&,*]{1,}/.test(v) == false || String(v).length < 4 || String(v).length > 10 ? false : true)
                },
                message: "Password is not valid , Password should be minimum 4 and maximum 10 characters long and It must contain a number and a capital character and a special character"
            }
        },
        age: {
            type: Number, required: [true, "Age is required !"], validate: {
                validator: function (v: number) {
                    return (v > 18)
                },
                message: "Age must be greater than 18"
            }
        },
        analysis: {
            type: Array, default:
                [
                    { "name": "Action", "value": 0 },
                    { "name": "Spy", "value": 0 },
                    { "name": "Horror", "value": 0 },
                    { "name": "Science-Fiction", "value": 0 },
                    { "name": "Comedy", "value": 0 },
                    { "name": "Thriller", "value": 0 },
                    { "name": "Crime", "value": 0 },
                    { "name": "Drama", "value": 0 },
                    { "name": "Supernatural", "value": 0 },
                    { "name": "Teen", "value": 0 },
                    { "name": "Romance", "value": 0 },
                    { "name": "Romantic-COmedy", "value": 0 }
                ]
        },
        totalTime: { type: Number, default: 0 },
        role: {
            type: String, required: [true, "Role is required !"],
            enum: {
                values: ["Admin", "User"],
                message: "Invalid Role Identity"
            }
        },
        createdBy:{
            type: Number, validate: {
                validator: function (v: string) {
                    return (String(v).length == 4 ? true : false)
                },
                message: "Id must be of 4 digits"
            }
        }
    },{
        timestamps:true
    })
export const UserModel = mongoose.model("users",Ottschema)
    