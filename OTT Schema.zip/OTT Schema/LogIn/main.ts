import express, { Request, Response } from 'express'
import 'dotenv/config'
import { LogInRouter } from './Routes/login'
import { HomeRouter } from './Routes/home'
import { UserModel } from './config/mongo'

const app = express()
app.listen(process.env.PORT)
app.use(express.json())
app.use("/login",LogInRouter)
app.use("/login/home",HomeRouter)

export interface UserType{
    id:number,
    name:string,
    username:string,
    password:string,
    age:number,
    analysis:Array<object>,
    totalTime: number,
    role:string
}


