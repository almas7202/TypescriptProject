let shows: any;
let usersData: any;
if (sessionStorage.length == 0) {
    $("#modal").attr("hidden", false)
    $("#btnLogOut").attr("hidden", true)
}
$.getJSON("src/users.json", function (data) {
    usersData = data
})
$.getJSON("src/data.json", function (data) {
    shows = data
    insertRow()
    display()
})
let genres: string[] = ["Action", "Spy", "Horror", "Science-Fiction", "Comedy", "Thriller", "Crime", "Drama", "Supernatural", "Teen", "Romance", "Romantic-Comedy"]
let startTime: number;
let endTime: number;
let day: Date;
let logInUser:object;
let choosenMovie:string;
let choosenGenre:string;
class user {
    id: number
    name: string
    username : string
    password: any
    age: number
    analysis: object[]
    TotalTime:number
    constructor(Id: number, Name: string,Username:string,Password: any, Age: number, Analysis: object[],TotalTime:number) {
        this.id = Id
        this.name = Name
        this.username=Username
        this.password = Password
        this.age = Age
        this.analysis = Analysis
        this.TotalTime=TotalTime
    }
}
$("#signUp").on("click", () => {
    $("#userId").val("")
    $("#password").val("")
    $("#verify").css("height", "62%")
    $("<label></lable>").text("Enter your name : ").attr("id", "nameLabel").insertAfter("#password")
    $("<br><br>").attr("class", "br").insertBefore("#nameLabel")
    $("<input>").attr("type", "text").attr("id", "name").attr("placeholder", "Name").attr("class", "inputbox").insertAfter("#nameLabel")
    $("<br><br>").attr("class", "br").insertBefore("#name")
    $("<label></lable>").text("Enter your age : ").attr("id", "ageLabel").insertAfter("#name")
    $("<br><br>").attr("class", "br").insertBefore("#ageLabel")
    $("<input>").attr("type", "number").attr("id", "age").attr("placeholder", "Age").attr("class", "inputbox").insertAfter("#ageLabel")
    $("<br><br>").attr("class", "br").insertBefore("#age")
    $("#btwBtn").text("Already a User ?")
    $("#signUp").attr("hidden", true)
    $("#signIn").attr("hidden", false)
    $("#register").attr("hidden", false)
    $("#logIn").attr("hidden", true)
})
function signInBox() {
    $("#userId").val("")
    $("#password").val("")
    $("#verify").css("height", "50%")
    $("#nameLabel,#name,#ageLabel,#age,#usernameLabel,#username").remove()
    $("#signUp").attr("hidden", false)
    $("#signIn").attr("hidden", true)
    $("#register").attr("hidden", true)
    $("#logIn").attr("hidden", false)
    $("#btwBtn").text("New User ?")
    $(".br").remove()
}
$("#signIn").on("click", () => {
    signInBox()
})
function usernameVerify() {
    let username: any = $("#userId").val()
    let pattern = /^[A-Z]{1,}[a-z]{3,}[0-9]{1,}$/
    if(username.match(pattern)==null){
        $("#error").text("Username must start with capital letter and end with number !").css("color", "red")
    }
    else{
        $("#error").text("")
    }
}
$("#userId").on("input",()=>{
    usernameVerify()
})
$("#logIn").on("click", () => {
    let username: any = $("#userId").val()
    let pass: any = $("#password").val()
    let userNewelyJoined = JSON.parse(window.localStorage.getItem(username))
        $.each(usersData.Users, (index, element) => {
            if ((element.username == username && element.password == pass) || (userNewelyJoined.username== username && userNewelyJoined.password == pass)) {
                $("#error").text("")
                $("#modal").attr("hidden", true)
                sessionStorage.setItem(`${username}`, "loggedIn")
                $("#intro").attr("hidden", false)
                setTimeout(() => {
                    $("#intro").attr("hidden", true)
                }, 2000)
                logInUser = new user(element.id,element.name, element.username,element.password, element.age, element.analysis,element.TotalTime)
                display()
                window.localStorage.setItem(logInUser.username,JSON.stringify(logInUser))
            }
            else {
                $("#error").text("User Not Found Credentials doesn't matched!").css("color", "red")
            }
        })
        $("#btnLogOut").attr("hidden", false)
})
$("#btnLogOut").on("click", () => {
    calculteTotalTime()
    sessionStorage.clear()
    $("#modal").attr("hidden", false)
    $("#btnLogOut").attr("hidden", true)
    $("#userId").val("")
    $("#password").val("")
    $("#name").val("")
    $("#age").val("null")
    $("#display").attr("hidden", false)
    $("#moviePage").attr("hidden", true)
    $.each(genres, (index: number, element: string) => {
        $(`#row${element}`).attr("hidden", false)
        $(`#heading${element}`).attr("hidden", false)
    })
})
function randomId() {
   return Math.floor(Math.random()*1000000+1)
}
$("#register").on("click", () => {
    let newUsername: any = $("#userId").val()
    let newPass: any = $("#password").val()
    let newName: any = $("#name").val()
    let newAge: any = $("#age").val()
    let newId:number = randomId()
    let analysis: object[] = [
        { "name": "Action", "value": 0 },
        { "name": "Spy", "value": 0 },
        { "name": "Horror", "value": 0 },
        { "name": "Science-Fiction", "value": 0 },
        { "name": "Comedy", "value": 0 },
        { "name": "Thriller", "value": 0 },
        { "name": "Crime", "value": 0 },
        { "name": "Drama", "value": 0 },
        { "name": "Supernatural", "value": 0 },
        { "name": "Teen", "value":0 },
        { "name": "Romance", "value": 0 },
        { "name": "Romantic-COmedy", "value":0 }
    ]
    if (newId != null && newPass != "" && newName != "" && newAge != null) {
        let newUser: user = new user(newId,newName,newUsername, newPass,newAge,analysis,0)
        $("#modal").attr("hiddeny",true)
        $("#btnLogOut").attr("hiddenlay",false)
        sessionStorage.setItem(`${newUsername}`, "loggedIn")
        window.localStorage.setItem(newUsername,JSON.stringify(newUser))
        signInBox()
    }
    else{
        $("#error").text("Any field cannot be empty!!")
    }
})
function insertRow() {
    $.each(shows[0], (index: string, element: object) => {
        let row = $("<tr></tr>").attr("id", `row${index}`).appendTo("#display")
    $.each(element, (i: string, subelement: object) => {
        let cell = $("<td></td>").appendTo(row)
        let card = $("<div></div>").attr("id", `card${i}`).attr("class", "card").appendTo(cell)
        let image = $("<img>").attr("id", `img${i}`).attr("class", "image").attr("src", `${subelement.thumbnail}`).appendTo(card)
        let div = $("<div></div>").attr("hidden", true).attr("class", "box").insertBefore(card)
        let boxImg = $("<div></div>").appendTo(div)
        $("<img>").attr("src", subelement.thumbnail).attr("alt", i).attr("class", "boxImg").appendTo(boxImg)
        $("<p></p>").text(subelement.title).attr("class", "boxTitle").appendTo(div)
        $("<p></p>").text(subelement.extract).attr("class", "boxDes").appendTo(div)
        let boxGenres = $("<p></p>").text(`Genres : ${index}`).attr("class", "boxGenres").appendTo(div)
        $("<span></span>").text(`Year : ${subelement.year}`).attr("class", "boxYear").appendTo(boxGenres)
        let ratingBox = $("<div></div>").attr("class", "ratingBox").text("Ratings : ").appendTo(div)
        let rating: number = subelement.ratings
        let count: number = 5;
        while (count != 0) {
            if (rating == 0.5) {
                $("<span></span>").attr("class", "fa fa-star-half-full checked").appendTo(ratingBox)
                rating -= 0.5
            }
            else if (rating == 0) {
                $("<span></span>").attr("class", "fa fa-star").appendTo(ratingBox)
            }
            else {
                $("<span></span>").attr("class", "fa fa-star checked").appendTo(ratingBox)
                rating -= 1
            }
            count -= 1
        }
        $(image).mouseover(function () {
            $(div).attr("hidden", false);
        });
        $(image).mouseout(function () {
            $(div).attr("hidden", true);
        });
        let btnPlay = $("<button></button>").attr("id", `btn${i}`).attr("class", "btn").text("Play").appendTo(card)
        $(btnPlay).on("click", () => {
            $("#display").attr("hidden", true)
            $("#moviePage").attr("hidden", false)
            movie(i, subelement)
            day = new Date()
            startTime = day.getHours() + (day.getMinutes() / 100)
            choosenMovie=i
            choosenGenre=index
        })
    })
})
}
$("#btnHome").on("click", () => {
    $("#display").attr("hidden", false)
    $("#moviePage").attr("hidden", true)
    $.each(genres, (index: number, element: string) => {
        $(`#row${element}`).attr("hidden", false)
        $(`#heading${element}`).attr("hidden", false)
    })
    calculteTotalTime()
})
$("#btnAction").on("click", () => {
    $("#display").attr("hidden", false)
    $("#moviePage").attr("hidden", true)
    $.each(genres, (index: number, element: string) => {
        if (element == "Action") {
            $(`#row${element}`).attr("hidden", false)
            $(`#heading${element}`).attr("hidden", false)
        }
        else {
            $(`.rowHeading${element}`).attr("hidden",true)
            $(`#heading${element}`).attr("hidden", true)
            $(`#row${element}`).attr("hidden", true)
        }
    })
    calculteTotalTime()
})
$("#btnHorror").on("click", () => {
    $(".rowHeading").attr("hidden",true)
    $("#display").attr("hidden", false)
    $("#moviePage").attr("hidden", true)
    $.each(genres, (index: number, element: string) => {
        if (element == "Horror") {
            $(`#row${element}`).attr("hidden", false)
            $(`#heading${element}`).attr("hidden", false)
        }
        else {
            $(`#heading${element}`).attr("hidden", true)
            $(`#row${element}`).attr("hidden", true)
        }
    })
    calculteTotalTime()
})
$("#btnComedy").on("click", () => {
    $(".rowHeading").attr("hidden",true)
    $("#display").attr("hidden", false)
    $("#moviePage").attr("hidden", true)
    $.each(genres, (index: number, element: string) => {
        if (element == "Comedy") {
            $(`#row${element}`).attr("hidden", false)
            $(`#heading${element}`).attr("hidden", false)
        }
        else {
            $(`#heading${element}`).attr("hidden", true)
            $(`#row${element}`).attr("hidden", true)
        }
    })
    calculteTotalTime()
})
function calculteTotalTime() {
    day = new Date()    
    endTime = day.getHours() + (day.getMinutes() / 100)
    let timeSpend = (Math.abs(endTime - startTime))     
    logInUser=JSON.parse(window.localStorage.getItem(sessionStorage.key(0)))
    logInUser.TotalTime = logInUser.TotalTime + timeSpend
    $.each(logInUser.analysis,(index:number,element:object)=>{
        if(element.name==choosenGenre){
            element.value = element.value+timeSpend
            logInUser.analysis.TotalTime += timeSpend
            console.log("User:"+logInUser.username);
        }
    })
    console.log("Movie name : "+choosenMovie+" Timespent : "+choosenGenre,timeSpend);
    window.localStorage.setItem(logInUser.username,JSON.stringify(logInUser))
}
function movie(i: string, subelement: object) {
    $("#movieHeading").text(i)
}   
function display() {
    $.each(usersData.Users, (index, element) => {
        if (sessionStorage.key(0) == element.id) {
            let analysisArr: object[] = element.analysis
            analysisArr.sort((a: object, b: object) => {
                return b.value - a.value
            })
            let row: any[] = $("#display tr").get()
            $.each(analysisArr, (i: number, subelement) => {
                $.each(row, (rowNumber: number, genreRow: object) => {
                    if (("row" + subelement.name) == genreRow.id) {
                        [row[rowNumber], row[i]] = [row[i], row[rowNumber]]
                    }
                })
            })
            $("#display").append(row)
        }
    })
}