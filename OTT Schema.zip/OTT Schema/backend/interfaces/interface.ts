export enum roles{
    "Admin" = "Admin",
    "User" = "User",
    "PremiumUser" = "PremiumUser"
}
export interface userLoginInfo{
    username:string,
    password:string
}

export interface userInfo{
    id:number,
    fname:string,
    lname:string,
    username:string,
    password:string,
    age:number,
    email:string,
    analysis_id:number,
    role:roles,
    createdBy:number,
    modifiedBy:number,
    createdAt:string,
    updatedAt:string
}

export interface analysisInfo{
    id:number,
    user_id:number,
    analysis:Array<any>,
    totalTime:number,
    createdBy:number,
    modifiedBy:number,
    createdAt:string,
    updatedAt:string
}

export interface userPassedInfo{
    id:number
    fname:string,
    lname:string,
    username:string,
    age:number,
    email:string,
    analysis_id:number,
    role:roles,
    createdBy:number,
    modifiedBy:number,
    createdAt:string,
    updatedAt:string
}

export interface roleChange{
    username:string,
    role:roles
}