import { Request, RequestHandler, Response } from "express";
import { Users } from "../schema/userSchema";
import { userPassedInfo } from "../interfaces/interface";
import { cryptor } from "./userControllers";
import jwt from 'jsonwebtoken'

export const premiumUserAnalysisPage:RequestHandler = (req:Request,res:Response)=>{
    try{
        const payload:string = String(jwt.decode(req.cookies["AccessToken"]))
        const userInfo:userPassedInfo = JSON.parse(cryptor.decrypt(payload))
        Users.aggregate([
            {
                $lookup: {
                    from: "analysisdatas",
                    localField: "analysis_id",
                    foreignField: "id",
                    as: "analysis",
                }
            }
        ])
        .then((val:any) => res.status(200).send(val[0]["analysis"]))
        .catch((val:any)=> res.status(401).send("Data not found"))
    }
    catch{
        res.status(404).send("Page not Found")
    }
    
    //Another Method of Populate
    // Users.find({ id: userInfo["id"] }).populate("analysis_id").then((val:any) => res.status(200).send(val))
}

export const HomePremiumUserPage:RequestHandler = (req:Request,res:Response)=>{
    try{
        res.status(200).send("Welcome Page for Premium User")
    }
    catch{
        res.status(404).send("Page not found")
    }
}
