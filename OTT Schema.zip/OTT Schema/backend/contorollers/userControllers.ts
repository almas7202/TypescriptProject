import { NextFunction, Request, RequestHandler, Response } from "express";
import { Users } from "../schema/userSchema";
import { AnalysisData } from "../schema/analysisSchema";
import { userInfo, userLoginInfo } from "../interfaces/interface";
import jwt from 'jsonwebtoken'
import Cryptr from "cryptr";
import 'dotenv'
import { IdCreator } from "../utils/idCreator";

export const cryptor: Cryptr = new Cryptr(String(process.env.SECRET_KEY))

export const userLoginController: RequestHandler = (req: Request, res: Response): void => {
    try {
        const userLoginInfo: userLoginInfo = {
            username: String(req.body["username"]),
            password: String(req.body["password"])
        }
        Users.findOne({ username: userLoginInfo.username })
            .then((value: any) => {
                if (value["password"] == userLoginInfo["password"]) {
                    const token = jwt.sign(
                        cryptor.encrypt(JSON.stringify(
                            {
                                id:value["id"],
                                fname: value["fname"],
                                lname: value["lname"],
                                username: value["username"],
                                age: value["age"],
                                email: value["email"],
                                analysis_id: value["analysis_id"],
                                role: value["role"],
                                updatedBy:value["updatedBy"],
                            }
                        )
                        ),
                        String(process.env.PRIVATE_KEY),
                        { algorithm: 'HS256' }
                    )
                    res.cookie("AccessToken", token).send("User Logged In Successfully !")
                }
                else {
                    res.status(401).send("Username doesn't match with password !")
                }
            })
            .catch(() => { res.status(401).send("Username not found !") })
    }
    catch {
        res.status(404).send("Page not found")
    }
}

export const userRegController: RequestHandler = async (req: Request, res: Response, next: NextFunction) => {
    try {
        let genratedId: number = 0
        await IdCreator(req.body["age"], req.body["fname"]).then((val: any) => genratedId = Number(val)).catch((err) => console.log(err))
        Users.insertMany([{
            id: genratedId,
            fname: req.body["fname"],
            lname: req.body["lname"],
            username: req.body["username"],
            password: req.body["password"],
            age: req.body["age"],
            email: req.body["email"],
            analysis_id: genratedId - 20000000,
            createdBy:genratedId,
            updatedBy:genratedId
        }])
        req.body["analysis_id"] = genratedId - 20000000
        next()
    }
    catch {
        res.status(404).send("Page not found")
    }
}

export const analysisRegController: RequestHandler = async (req: Request, res: Response) => {
    try {
        let user_number = 0
        await Users.find().then((value: Array<any>) => user_number = value.length)
        AnalysisData.insertMany([
            {
                id: req.body["analysis_id"],
                analysis: [],
                totalTime: 0,
                createdBy:req.body["analysis_id"]+20000000,
                updatedBy:req.body["analysis_id"]+20000000
            }
        ])
            .then(() => {
                res.status(200).send("User Registered Successfully !")
            })
            .catch((err: Error) => {
                res.status(401).send(err)
            })
    }
    catch {
        res.status(404).send("Page not found")
    }
}

export const HomeUserPage:RequestHandler = (req:Request,res:Response)=>{
    try{
        res.status(200).send("Welcome Page for everyone")
    }
    catch{
        res.status(404).send("Page not found")
    }
}