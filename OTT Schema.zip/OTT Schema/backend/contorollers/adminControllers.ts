import { Request, Response } from "express";
import { roleChange, userPassedInfo } from "../interfaces/interface";
import { Users } from "../schema/userSchema";
import jwt from 'jsonwebtoken'
import { cryptor } from "./userControllers";

export const changeUserRole = (req: Request, res: Response) => {
    try {
        const payload: string = String(jwt.decode(req.cookies["AccessToken"]))
        const userInfo: userPassedInfo = JSON.parse(cryptor.decrypt(payload))
        const userForChange: roleChange = req.body
        Users.findOneAndUpdate({ username: userForChange["username"] }, { role: userForChange["role"] ,updatedBy:userInfo["id"]})
            .then(() => res.status(200).send("Role Succesfully changed"))
            .catch(() => res.status(404).send("Username not found !"))
    }
    catch {
        res.status(404).send("Page Not found")
    }
}