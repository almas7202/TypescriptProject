import express from "express";
import { authenticateUser, authorisePremiumUser } from "../middlware/auth";
import { HomeUserPage } from "../contorollers/userControllers";

export const HomeUser = express.Router()

HomeUser.route("/").get(authenticateUser,HomeUserPage)