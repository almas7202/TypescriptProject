import express from "express";
import { authenticateUser, authoriseAdmin } from "../middlware/auth";
import { changeUserRole } from "../contorollers/adminControllers";
import { validator } from "../validationSchema/registerSchema";
import { subscribeSchema } from "../validationSchema/subscribeSchema";

export const RoleRouter = express.Router()

RoleRouter.route("/").put(validator.body(subscribeSchema),authenticateUser,authoriseAdmin,changeUserRole)