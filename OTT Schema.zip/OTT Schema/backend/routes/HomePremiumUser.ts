import express from "express";
import { authenticateUser, authorisePremiumUser } from "../middlware/auth";
import { HomePremiumUserPage } from "../contorollers/premiumuserControllers";

export const HomePremiumUser = express.Router()

HomePremiumUser.route("/").get(authenticateUser,authorisePremiumUser,HomePremiumUserPage)