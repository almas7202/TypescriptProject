import express from "express";
import { userLoginController } from "../contorollers/userControllers";
import { validator } from "../validationSchema/registerSchema";
import { loginSchema } from '../validationSchema/logimSchema'

export const LoginRouter = express.Router()

LoginRouter.route("/").post(validator.body(loginSchema),userLoginController)