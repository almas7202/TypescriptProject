import express from "express";
import { authenticateUser, authorisePremiumUser } from "../middlware/auth";
import { premiumUserAnalysisPage } from "../contorollers/premiumuserControllers";

export const AnalysisPremiumUser = express.Router()

AnalysisPremiumUser.route("/").get(authenticateUser,authorisePremiumUser,premiumUserAnalysisPage)