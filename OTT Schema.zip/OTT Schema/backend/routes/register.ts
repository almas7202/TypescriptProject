import express from "express";
import { analysisRegController, userRegController } from "../contorollers/userControllers";
import { registerSchema, validator } from "../validationSchema/registerSchema";

export const RegisterRouter = express.Router()

RegisterRouter.route("/").post(validator.body(registerSchema),userRegController,analysisRegController)