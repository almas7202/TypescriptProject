import { Users } from "../schema/userSchema";

export const IdCreator = async(age: number, fname: string) => {
        let flag: boolean = true
        let GenratedId:number = 0
        while (flag){
            GenratedId = age*100 + (fname.charCodeAt(0)) * 10000 + 85000000 + String(process.env.ID_KEY).charCodeAt(Math.floor(Math.random()*100));
            await Users.find({ id: GenratedId })
                .then((val:Array<any>)=>{
                    if(val.length==0){
                        flag=false  
                    }
            })
        }
        return GenratedId
}