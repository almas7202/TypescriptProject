import { NextFunction, Request, RequestHandler, Response } from "express";
import jwt from "jsonwebtoken";
import { roles, userPassedInfo } from "../interfaces/interface";
import { cryptor } from "../contorollers/userControllers";
import { Users } from "../schema/userSchema";

export const authenticateUser: RequestHandler = (req: Request, res: Response, next: NextFunction) => {
    const payload:string = String(jwt.decode(req.cookies["AccessToken"]))
    const userInfo:userPassedInfo = JSON.parse(cryptor.decrypt(payload))
    Users.findOne({username:userInfo["username"]})
        .then((value:any)=>{
            const user:userPassedInfo = value
            if(user["fname"]==userInfo["fname"] && user["lname"]==userInfo["lname"] && user["email"]== userInfo["email"]){
                res.status(200)
                next()
            }
            else{
                res.status(401).send("Unauthenticated User !")
            }
        })
        .catch(()=>{
            res.status(401).send("Unauthenticated User !")
        })
}

export const authoriseAdmin:RequestHandler = (req:Request,res:Response,next:NextFunction)=>{
    const payload:string = String(jwt.decode(req.cookies["AccessToken"]))
    const userInfo:userPassedInfo = JSON.parse(cryptor.decrypt(payload))
    if(userInfo["role"]==roles["Admin"]){
        res.status(200)
        next()
    }
    else{
        res.status(401).send("Unauthorised User !")
    }
}

export const authorisePremiumUser:RequestHandler = (req:Request,res:Response,next:NextFunction)=>{
    const payload:string = String(jwt.decode(req.cookies["AccessToken"]))
    const userInfo:userPassedInfo = JSON.parse(cryptor.decrypt(payload))
    if(userInfo["role"]==roles["PremiumUser"]){
        res.status(200)
        next()
    }
    else{
        res.status(401).send("Unauthorised User !")
    }
}