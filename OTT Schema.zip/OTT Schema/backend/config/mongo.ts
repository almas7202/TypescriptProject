import mongoose from 'mongoose'
import 'dotenv/config'

export const connectMongo:Function = ():void=>{
    mongoose.connect(String(process.env.MONGODB))
        .then(()=>console.log("Database Connected !"))
        .catch((err:Error)=>console.log(`Error : ${err}`))
}