import express from 'express'
import 'dotenv/config'
import { connectMongo } from './config/mongo'
import { RegisterRouter } from './routes/register'
import { LoginRouter } from './routes/login'
import { RoleRouter } from './routes/role'
import cookieParser from 'cookie-parser'
import { HomePremiumUser } from './routes/HomePremiumUser'
import { HomeUser } from './routes/HomeUser'
import { AnalysisPremiumUser } from './routes/AnalysisPremiumUser'

const app = express()

app.listen(process.env.PORT)
app.use(express.json())
app.use(cookieParser())

app.use("/register",RegisterRouter)
app.use("/login",LoginRouter)
app.use("/subscriber",RoleRouter)
app.use("/homePr",HomePremiumUser)
app.use("/home",HomeUser)
app.use("/AnalysisPr",AnalysisPremiumUser)

connectMongo()
