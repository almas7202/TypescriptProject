import mongoose, { Schema } from "mongoose";

const UserSchema: Schema = new mongoose.Schema({
    id: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        }
    },
    fname: {
        type: String, min: 3, max: 10
    },
    lname: {
        type: String, min: 3, max: 10
    },
    username: {
        type: String,
        required: [true, "Username is required field !"],
        validate: {
            validator: (v: string) => {
                return (/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}/.test(v) == false || String(v).length < 4 || String(v).length > 10 ? false : true)
            },
            message:
                "Username must contain capital letter , small letter and number with length of characters between 4 and 10"
        }
    },
    password: {
        type: String,
        required: [true, "Password is required field"],
        validate: {
            validator: (v: string) => {
                return (/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}[@,#,$,%,!,^,&,*]{1,}/.test(v) == false || String(v).length < 4 || String(v).length > 10 ? false : true)
            }
        }
    },
    age: {
        type: Number, min: [18, "18+ age is compulsory."]
    },
    email: {
        type: String,
        required: [true, "Email is required"],
        validate: {
            validator: (v: string) => {
                return (/[a-z]{1,}[@]{1}[a-z]{1,}[.]{1}/).test(v)
            }
        }
    },
    analysis_id: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        },
    },
    role: {
        type: String, default : "User"
    },
    createdBy: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        }
    },
    updatedBy: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        }
    }
},
    {
        timestamps: true
    })

export const Users = mongoose.model("Users", UserSchema)