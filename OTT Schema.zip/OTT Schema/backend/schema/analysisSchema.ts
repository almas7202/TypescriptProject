import mongoose, { Schema } from "mongoose"

const AnalysisSchema: Schema = new mongoose.Schema({
    id: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        }
    },
    analysis: {
        type: Array,
        default:[]
    },
    totalTime: {
        type: Number,
        required: true,
        min: 0.0
    },
    createdBy: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        }
    },
    updatedBy: {
        type: Number,
        validate: {
            validator: (v: number) => {
                return v >= 1000000
            },
            message: "Id must be of minimum 4 digits."
        }
    }
})

export const AnalysisData = mongoose.model("AnalysisData",AnalysisSchema)
