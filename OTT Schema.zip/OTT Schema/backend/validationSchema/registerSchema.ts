import { createValidator } from "express-joi-validation";
import joi from 'joi'

export const validator = createValidator()

export const registerSchema = joi.object({
    fname: joi.string().required().min(3).max(10),
    lname: joi.string().required().min(3).max(10),
    username: joi.string().required().alphanum().min(4).max(10).pattern(/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}/).message("Username must contain capital letter , small letter and number with length of characters between 4 and 10"),
    password: joi.string().required().min(4).max(10).pattern(/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}[@,#,$,%,!,^,&,*]{1,}/).message("Password must contain capital letter , small letter and number with length of characters between 4 and 10"),
    age: joi.number().required().min(18).message("18+ age is compulsory."),
    email: joi.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net'] } })
})