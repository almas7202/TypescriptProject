import joi from 'joi'

export const loginSchema = joi.object({
    username: joi.string().required().alphanum().min(4).max(10).pattern(/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}/).message("Username must contain capital letter , small letter and number with length of characters between 4 and 10"),
    password: joi.string().required().min(4).max(10).pattern(/[A-Z]{1,}[a-z]{1,}[0-9]{1,}[ ]{0}[@,#,$,%,!,^,&,*]{1,}/).message("Password must contain capital letter , small letter and number with length of characters between 4 and 10")
})