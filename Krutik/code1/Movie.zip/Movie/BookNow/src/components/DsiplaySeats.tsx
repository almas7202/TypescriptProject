import { useState } from "react";
export const DisplaySeats = (seat : any , color:any ,selectedSeats:any,setSelectedSeats:Function) => {
    const [colorToApply,setColor] = useState(color)
    const handleCheck=(e:any)=>{
        {e.target.checked==true ? seatChecked(e) : seatUnchecked(e)}
    }
    const seatChecked=(e:any)=>{
        const {id}:any = e.target       
        setSelectedSeats([...selectedSeats,id])  
        setColor("#2196F3");
    }
    const seatUnchecked=(e:any)=>{
        const {id}:any = e.target
        setColor("green")
        selectedSeats.splice(selectedSeats.indexOf(id),1)
        setSelectedSeats([...selectedSeats])                
    }
    return (
        <>
            <label className="container">
                <input type="checkbox" id={seat.id} disabled={seat.status==false ? true : false} onChange={(e)=>handleCheck(e)}/>
                <div className="checkmark">
                    <ul>
                        <div className="seat" key={seat.index} id={"Seat"+seat.id}>
                            <li key={"A" + seat.id}>
                                <div className="seatSideLeftHorz" key={"A" + seat.id} style={{backgroundColor:colorToApply,borderColor:colorToApply}}></div>
                            </li>
                            <li key={"B" + seat.id}>
                                <div className="seatSideLeft" key={"B" + seat.id} style={{backgroundColor:colorToApply,borderColor:colorToApply}}></div>
                            </li>
                            <li key={"C" + seat.id}>
                                <div className="seatTop" style={{backgroundColor:colorToApply,borderColor:colorToApply}}><h2>{seat.name}</h2></div>
                                <div className="seatBottom" key={"C2" + seat.id} style={{backgroundColor:colorToApply,borderColor:colorToApply}}></div>
                                <div className="lowerBox" key={"C3" + seat.id} style={{backgroundColor:colorToApply,borderColor:colorToApply}}></div>
                            </li>
                            <li key={"D" + seat.id}>
                                <div className="seatSideRight" key={"D" + seat.id} style={{backgroundColor:colorToApply,borderColor:colorToApply}}></div>
                            </li>
                            <li key={"E" + seat.id}>
                                <div className="seatSideRightHorz" key={"E" + seat.id} style={{backgroundColor:colorToApply,borderColor:colorToApply}}></div>
                            </li>
                        </div>
                    </ul>
                </div>
            </label>
        </>
    )
}