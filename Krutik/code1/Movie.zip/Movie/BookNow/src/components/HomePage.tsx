import { useState, useEffect } from "react"
import { DisplaySeats } from "./DsiplaySeats"
import MovieData from '../data/Movies.json'
import { Link, useParams } from "react-router-dom"

export const HomePage = ({ seatsArr, selectedSeats, setSelectedSeats }: any) => {

    const { movieScreen, movieId }: any = useParams()
    const [findMovie, setFindMovie]: any = useState<object>({})
    const setMovie = () => {
        MovieData.map((movie) => {
            {
                movie.movieId == Number(movieId) ? setFindMovie(movie) : false
            }
        })
    }
    useEffect(() => {
        setMovie()
    })
    let screenName: string = (String(findMovie.screen)).substr(3, 1)
    return (
        <div>
            <h1 className="MovieName">
                {findMovie.moviename}
            </h1>
            <div id="imageContainer">
                <img src="../../../src/data/screen.png" />
            </div>
            <h1 className="MovieName">
                Screen-{screenName}
            </h1>
            <table className="seat-Container">
                <tbody>
                    <tr>
                        <td colSpan={10} align="center" className="MembersHeading">Silver Members Price=120/- Rs</td>
                    </tr>
                    <tr className={'grid-container-silver-' + movieScreen}>
                        {
                            seatsArr[0][movieScreen].SilverMembers.map((seat: any, index: number) =>
                            (
                                <td key={index}>
                                    {seat.status == true ? DisplaySeats(seat, "green", selectedSeats, setSelectedSeats) : DisplaySeats(seat, "gray", selectedSeats, setSelectedSeats)}
                                </td>
                            ))
                        }
                    </tr>
                    <tr>
                        <td colSpan={10} align="center" className="MembersHeading">Gold Members Price=200/- Rs</td>
                    </tr>
                    <tr className={'grid-container-gold-' + movieScreen}>
                        {
                            seatsArr[0][movieScreen].GoldMembers.map((seat: any, index: number) =>
                            (
                                <td key={index}>
                                    {seat.status == true ? DisplaySeats(seat, "green", selectedSeats, setSelectedSeats) : DisplaySeats(seat, "gray", selectedSeats, setSelectedSeats)}
                                </td>
                            ))
                        }
                    </tr>
                </tbody>
            </table>
            {
                selectedSeats.length == 0 ? <></> : <>
                    <Link to={"/movies/" + movieScreen + "/" + movieId + "/book"}>
                        <div id="bookbtn">
                            <button className="bookbtn">Book</button>
                        </div>
                    </Link>
                </>
            }
        </div>
    )
}