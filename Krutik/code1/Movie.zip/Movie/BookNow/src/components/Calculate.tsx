import { Params, useParams } from 'react-router'
import SeatsData from '../data/seats.json'
import { Link } from 'react-router-dom';
import { calculateProps } from '../App';

function Calculate({selectedSeats,seatsArr,setSelectedSeats,setSeatsArr}:calculateProps) {
    let selectedSeatsArr: Array<object> = []
    let totalPrice: any = 0;   
    const  movieScreen:string | undefined= useParams().movieScreen
    const handleBookMore = () => {
        selectedSeats.map((SelectedSeat:any)=>{
            seatsArr[0][movieScreen].GoldMembers.map((seat:any)=>{
                {
                    seat.id==SelectedSeat ? seat.status=false : false
                }
            })  
            seatsArr[0][movieScreen].SilverMembers.map((seat:any)=>{
                {
                    seat.id==SelectedSeat ? seat.status=false : false
                }
            })
        })
        setSeatsArr([...seatsArr])
        setSelectedSeats([])  
    }
    {
        selectedSeats.map((seatId: any) => {
            SeatsData[0][movieScreen].GoldMembers.map((element: any) => {
                {
                    element.id == seatId ? selectedSeatsArr.push(element) : false
                }
            })
            SeatsData[0][movieScreen].SilverMembers.map((element: any) => {
                {
                    element.id == seatId ? selectedSeatsArr.push(element) : false
                }
            })
        })
        selectedSeatsArr.map((seat: any) => {
            totalPrice += seat.price
        })
    }
    return (
        <div className="bill">
            <div>
                <h1 style={{ marginTop: "50px", color: "green" }}>
                    Invoice
                </h1>
            </div>
            <table className='invoiceTable'>
                <tbody>
                    <tr>
                        <td colSpan={2}>
                            <hr />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Number of Seats :
                        </td>
                        <td>
                            {selectedSeats.length}
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Seat Numbers :
                        </td>
                        <td>
                            {
                                selectedSeatsArr.map(
                                    (seat: any, index: number) => (<p key={index}>{seat.name}</p>)
                                )
                            }
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Total Price :
                        </td>
                        <td>
                            {(totalPrice).toFixed(2)}/- Rs.
                        </td>
                    </tr>
                    <tr>
                        <td>
                            GST (18%):
                        </td>
                        <td>
                            {(totalPrice * 0.18).toFixed(2)}/- Rs.
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Total Bill Amount :
                        </td>
                        <td>
                            {(totalPrice += totalPrice * 0.18).toFixed(2)}/- Rs.
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <Link to="/">
                                <button className='bookbtn' onClick={() => handleBookMore()}>Book More</button>
                            </Link>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}
export default Calculate