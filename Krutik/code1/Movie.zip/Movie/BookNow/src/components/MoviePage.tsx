import Movies from '../data/Movies.json'
import { Link } from 'react-router-dom'
export const MoviePage = () => {
    return (
        <>
            <div id='Movie-Page-Background'>
                <div className='Icon-Section'>
                        <img src="./src/data/icon.jpeg" />
                </div>
                <div className="card-grid">
                    {
                        Movies.map((movie, index) => (
                            <div className='card' key={index}>
                                <img src={movie.img} className='MoviesImg' />
                                <div className='MovieTitle'>
                                    <h3>{movie.moviename}</h3>
                                </div>
                                <Link to={"/movies/"+movie.screen+"/"+movie.movieId}>
                                    <button className='bookbtn'>Book Now</button>
                                </Link>
                            </div>
                        ))
                    }
                </div>
            </div>
        </>
    )
}