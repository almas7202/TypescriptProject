import { useState } from 'react'
import './App.css'
import { HomePage } from './components/HomePage'
import { MoviePage } from './components/MoviePage'
import seatData from './data/seats.json'
import { BrowserRouter, Routes, Route } from "react-router-dom"
import Calculate from './components/Calculate'

export interface calculateProps {
  seatsArr:Array<object>,
  setSeatsArr:React.Dispatch<React.SetStateAction<object[]>>,
  selectedSeats:Array<number>,
  setSelectedSeats:React.Dispatch<React.SetStateAction<number[]>>
}

function App() {
  
  const [seatsArr, setSeatsArr] = useState<Array<object>>(seatData)
  const [selectedSeats, setSelectedSeats] = useState<Array<number>>([])
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index element={<MoviePage />} />
          <Route path="/movies/:movieScreen/:movieId" element={<HomePage seatsArr={seatsArr} selectedSeats={selectedSeats} setSelectedSeats={setSelectedSeats} />}/>
          <Route path='/movies/:movieScreen/:movieId/book' element={<Calculate selectedSeats={selectedSeats} seatsArr={seatsArr} setSelectedSeats={setSelectedSeats} setSeatsArr={setSeatsArr}/>} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
