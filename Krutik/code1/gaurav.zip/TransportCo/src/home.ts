import * as res from "./json/source_destination.json";
import * as truck_options from "./truck_options";

document.getElementById("login").addEventListener("click", function () {
  window.location.href = "registration/index.html"
});

const parseURL = new URL(window.location.href);
const email = parseURL.searchParams.get("email");

document.getElementById("user").innerText = email;

for (let i = 0; i < res.cities.length; i++) {
  document.getElementById("source").innerHTML += `<option value="${res.cities[i]}" class="text-light">${res.cities[i]}</option>`
  document.getElementById("destination").innerHTML += `<option value="${res.cities[i]}" class="text-light">${res.cities[i]}</option>`
}

document.getElementById("fare").addEventListener("click", function(){
    $("#heading").hide();
    $("#form").hide();
    $("#abc").html(` <div class="bg-secondary border-top row pt-2 pb-2">
  <div class="text-light col d-flex justify-content-end" id="top_source">
        
  </div>
  <div class="text-light col d-flex justify-content-center" id="dis">

  </div>
  <div class="text-light col" id="top_destination">
  </div>
  </div>
    
  <br>
  <div class="container">
  <select class="form-select bg-secondary text-light" aria-label="Default select example" id="opt">
    <option value="" selected>Select Weight</option>
    <option value="1">01 Tons</option>
    <option value="5">05 Tons</option>
    <option value="10">10 Tons</option>
    <option value="15">15 Tons</option>
    <option value="20">20 Tons</option>
    <option value="25">25 Tons</option>
    <option value="30">30 Tons</option>
    <option value="35">35 Tons</option> 
  </select>
  <div id="card" class="mt-2" style="
  display: flex;
  flex-wrap: wrap;"></div>
  </div>`)

  new truck_options.name1();

  var source:string = $("#source").val();
  var destination:string = $("#destination").val();
  
  $("#top_source").html(
    `<div>${source}, Gujarat, India</div>`
  )
  $("#top_destination").html(
    `<div>${destination}, Gujarat, India</div>`
  )
  $("#dis").html(
    `<div> --> ${res.dis[distance(source, destination)-1].distance} KMS --></div>`
  )

  console.log(res.dis[distance(source, destination)-1].id);
  

})

function distance(src:string, des:string){
  for (let i = 0; i < res.dis.length; i++) {
    if(res.dis[i].source == src && res.dis[i].destination == des){
      return res.dis[i].id;
    }
  }
}
