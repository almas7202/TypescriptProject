import * as truck_options from "./json/truck_option.json"
const parseURL = new URL(window.location.href);
const id = parseURL.searchParams.get("id");
console.log(id);

class data {
    yourName: string;
    yourCity: string;
    email: string;
    phone: number;
    address: string;
    address2: string;
    state: string;
    country: string;
    zipcode: number;
    areacode: number;
    constructor(yourName: string,
        yourCity: string,
        email: string,
        phone: number,
        address: string,
        address2: string,
        state: string,
        country: string,
        zipcode: number,
        areacode: number) {
            this.yourName = yourName;
            this.yourCity = yourCity;
            this.email = email;
            this.phone = phone;
            this.address = address;
            this.address2 = address2;
            this.state = state;
            this.country = country;
            this.zipcode = zipcode;
            this.areacode = areacode;
    }
}

document.getElementById("logout").addEventListener("click", function():void{
    window.location.href = "index.html";
})

document.getElementById("truck_image").setAttribute("src", `${truck_options.options[id - 1].image}`);
let orders:any[] =localStorage.getItem('orders') ? JSON.parse(localStorage.getItem('orders')) : [];


document.getElementById("book_btn").addEventListener("click", function () {
    var name: string = document.getElementById("yourname").value;
    var yourCity: string = document.getElementById("yourcity").value;
    var email: string = document.getElementById("email").value;
    var phone: number = document.getElementById("phone").value;
    var address: string = document.getElementById("address").value;
    var address2: string = document.getElementById("address2").value;
    var state: string = document.getElementById("state").value;
    var country: string = document.getElementById("country").value;
    var zipCode: number = document.getElementById("post").value;
    var areaCode: number = document.getElementById("area").value;

    let data1 = new data(name, yourCity, email, phone, address, address2, state, country, zipCode, areaCode);
    orders.push(data1);
    localStorage.setItem("orders", JSON.stringify(orders))

    alert(`${truck_options.options[id - 1].tname} \n Driver name: ${truck_options.options[id - 1].dname} \n Truck Number: ${truck_options.options[id - 1].tnumber} \n Contact Number: ${truck_options.options[id - 1].contact} \n you can contact him and book your truck.`);
    
    $("#book_form").hide();
})




