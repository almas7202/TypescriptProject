import * as truck_options from "./json/truck_option.json";
import * as res from "./json/source_destination.json";
export class name1{
    constructor(){
       redun(truck_options.options);
       
       $("#opt").change(function () {  
        document.getElementById("card").innerHTML = "";
        var arr:any[] = [];
            for (let i = 0; i < truck_options.options.length; i++) {
                if ($("#opt").val() == truck_options.options[i].capacity) {
                  arr.push(truck_options.options[i])
                }
            }
        console.log(arr);
        redun(arr);
       })
    
    }
}

function redun(par: any[]) {
    for (let j = 0; j < par.length; j++) {
        document.getElementById("card").innerHTML += `<div class="card" id="truck${par[j].id}" style="width: 300px;">
                                                        <img src="${par[j].image}" style="width:100%; height:200px" id="image">
                                                        <div class="container mb-1">
                                                            <h4><b id="name">${par[j].tname}</b></h4> 
                                                            <p id="instructions">Capacity: ${par[j].capacity}</p> 
                                                        </div>
                                                        <button type="button" class="btn btn-outline-secondary trk_btn" data-truck-id="${par[j].id}" id="select${par[j].id}"><a id="select_${par[j].id}" href="order.html?id=${par[j].id}">Select</a></button>
                                                    </div>`;
    }

    const buttons = document.querySelectorAll('.trk_btn');
    buttons.forEach(button => {
        button.addEventListener('click', showDetails);
    });

    function showDetails(event: any) {

        const truckId = event.target.getAttribute('data-truck-id');
        document.getElementById(`select_${truckId}`).setAttribute("href", `order.html?id=${truckId}`);
        
        // localStorage.setItem(res.dis[distance(source, destination)-1].id);
        
        // localStorage.setItem()
    }
}

// function distance(src:string, des:string){
//     for (let i = 0; i < res.dis.length; i++) {
//       if(res.dis[i].source == src && res.dis[i].destination == des){
//         return res.dis[i].id;
//       }
//     }
//   }