function validateForm():void{
  let data:any[] =localStorage.getItem('details') ? JSON.parse(localStorage.getItem('details')) : [];;
  let formData:any ={
          "name":document.getElementById("uName").value,
          "email":document.getElementById("uEmail").value,
          "contactno":document.getElementById("uContactno").value,
          "password":document.getElementById("uPassword").value,
          "confirmpassword":document.getElementById("confirmPassword").value
      }
      data.push(formData);
      if(localStorage){
          localStorage.setItem("details", JSON.stringify(data));
      } 
}

function verifyPassword(input:any){
  if(input.value != document.getElementById("uPassword").value){
      input.setCustomValidity("Password Must be Matching");
  }else{
      input.setCustomValidity("");
  }
}

function emailExist(value:any){
  let existemail:any = JSON.parse(localStorage.getItem("details"));
  let emailid:any = existemail.map((email:any,i:any,existemail:any) =>{
      return existemail[i].email;
  });
   let getexistemail:any = emailid.filter((email:any)=>{
      if(email == value.value){
          value.setCustomValidity('email exist. try something else');
      }else{
          value.setCustomValidity("");
      }
  });
}

  const form:any = document.getElementById("registerForm");
  form.addEventListener("submit", function(e:any){
      e.preventDefault();
      form.reset();
      document.getElementById("thankYou").style.display="block";
      form.style.display="none";
  });

  function showHide(show:any, hide:any){
      let showEle:any = document.getElementById(show);
      let hideEle:any = document.getElementById(hide);
      showEle.style.display="block";
      hideEle.style.display="none";
  }

  function loginUser(){
      let loginEmail:any = document.getElementById("uemailId").value;
      let loginPass:any =  document.getElementById("ePassword").value;
      let matchEmail:any = JSON.parse(localStorage.getItem("details"));
      let emailArray:any[] =[];
      let passArray:any[] =[];
       let result:any = matchEmail.map((email:any, i:any, matchEmail:any) =>{
         emailArray.push(matchEmail[i].email);
         passArray.push(matchEmail[i].password);
      });

      if(emailArray.indexOf(loginEmail) > -1 && passArray.indexOf(loginPass) > -1){
          window.location.href = `home.html?email=${loginEmail}`;  
      }else if(loginEmail == "admin@gmail.com" && loginPass == "admin"){
           window.location.href = `admin.html`
      }else{
          alert("You have no registered with us");
      }    
  }
  const loginForm:any = document.getElementById("logIn");
  loginForm.addEventListener("submit", function(e:any){
      e.preventDefault();
  });