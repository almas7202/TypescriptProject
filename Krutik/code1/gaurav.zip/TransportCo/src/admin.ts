document.getElementById("logout").addEventListener("click", function():void{
    window.location.href = "index.html";
})

var table:any = document.getElementById("table");
var key:any = Object.keys(localStorage);
var value:any = localStorage.getItem("orders");
var data:any = JSON.parse(value);
for (let i = 0; i < data.length; i++) {
    var row:any = table.insertRow();
    row.insertCell(0).innerHTML = `${data[i].yourName}`;
    row.insertCell(1).innerHTML = `${data[i].email}`;
    row.insertCell(2).innerHTML = `${data[i].phone}`;
    row.insertCell(3).innerHTML = `${data[i].address}`;
    row.insertCell(4).innerHTML = `${data[i].address2}`;
}

