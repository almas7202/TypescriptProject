import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Home } from './Components/Home'
import { useState } from 'react'
import { Confirm } from './Components/Confirm'
import { Payment } from './Components/Payment'

export interface Flight {
  flightId: number,
  price: number
}
function App() {
  const [BookedFlight, setBookedFlight] = useState<Flight>(
    {
      flightId: 0,
      price: 0
    }
  )
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index element={<Home setBookedFlight={setBookedFlight} />} />
          <Route path='confirm' element={<Confirm BookedFlight={BookedFlight}/>} />
          <Route path='payment' element={<Payment />}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
