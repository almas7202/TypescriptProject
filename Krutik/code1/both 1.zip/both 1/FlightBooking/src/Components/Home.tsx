import flightsData from '../Data/flights.json'
import sourceData from '../Data/source.json'
import destinationData from '../Data/destinations.json'
import { Flight } from '../App'
import { useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'

interface HomeProps {
    setBookedFlight: React.Dispatch<React.SetStateAction<Flight>>
}
export interface flightObjectType {
    flightID: number,
    name: string,
    price: number,
    sourceID: number,
    destinationID: number,
    departureDate: string
}
export interface cityObjectType {
    id: number,
    name: string
}

export const Home = ({ setBookedFlight }: HomeProps) => {
    let filterValue = 200
    const nav = useNavigate()
    let [showFlights, setShowFlights] = useState<Array<flightObjectType>>
        (flightsData)
    let [destinationUpdate, setDestinationUpdate] = useState<Array<cityObjectType>>(destinationData)
    const handleDestination = () => {
        destinationUpdate = []
        showFlights.map((flight) => {
            destinationData.map((des) => {
                {
                    flight.destinationID == des.id ? destinationUpdate.push(des) : false
                }
            })
            setDestinationUpdate([...destinationUpdate])
        })
    }
    useEffect(() => {
        handleDestination()
    }, [showFlights])
    const handleSource = (e: any) => {
        const { name, value } = e.target
        { name == 'destinationID' ? true : showFlights = flightsData }
        setShowFlights([...showFlights.filter((flight: any) => (flight[name] == value))])
    }
    const handleBook = (e: any) => {
        flightsData.map((flight) => {
            flight.flightID == (e.target.id).substr(6, 1) ? setBookedFlight({ ...{ flightId: flight.flightID, price: flight.price } }) : false
        })
        nav('/confirm')
    }
    const handleSort = () => {
        showFlights.sort((a, b) => {
            let P1 = a.price
            let P2 = b.price
            return (P1 - P2)
        })
        setShowFlights([...showFlights])
    }
    const handleFilter = () => {
        showFlights = flightsData
        showFlights = showFlights.filter((flight) => (
            flight.price < filterValue
        ))
        setShowFlights(showFlights)
    }
    const handleChange = (e:any)=>{
        const {value} = e.target
        filterValue = value
    }
    return (
        <div>
            <div className='InputTableContainer'>
            <form method="get">
                <table className='InputTable'>
                    <tbody>
                        <tr>
                            <td>
                                <label>Select Source :</label>
                            </td>
                            <td>
                                <select name='sourceID' onChange={(e) => handleSource(e)}>
                                    <option value="" hidden>Select Source City</option>
                                    {
                                        sourceData.map((city, index) => (
                                            <option key={index} value={city.id}>{city.name}</option>
                                        ))
                                    }
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Select Destination :</label>

                            </td>
                            <td>
                                <select name='destinationID' onChange={(e) => handleSource(e)}>
                                    <option value="" hidden>Select Destination City</option>
                                    {
                                        destinationUpdate.map((city, index) => (
                                            <option key={index} value={city.id}>{city.name}</option>
                                        ))
                                    }
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
            </div>
            <div className='ListTableContainer'>
            <table className='ListTable'>
                <tbody>
                    <tr className='headingRow'>
                        <th>
                            Flight Name
                        </th>
                        <th>
                            Source City
                        </th>
                        <th>
                            Destination City
                        </th>
                        <th>
                            Date of Departure(YYYY-MM-DD)
                        </th>
                        <th>
                            Price
                        </th>
                        <th></th>
                    </tr>
                    {
                        showFlights.map((flight, index) => (
                            <tr key={index}>
                                <td>
                                    {flight.name}
                                </td>
                                <td>
                                    {
                                        sourceData.map((city) => (
                                            city.id == flight.sourceID ? city.name : false
                                        )
                                        )
                                    }
                                </td>
                                <td>
                                    {
                                        destinationData.map((city) => (
                                            city.id == flight.destinationID ? city.name : false
                                        )
                                        )
                                    }
                                </td>
                                <td>
                                    {
                                        flight.departureDate
                                    }
                                </td>
                                <td>
                                    {
                                        flight.price
                                    }
                                </td>
                                <td>
                                    <button id={"Flight" + flight.flightID} onClick={(e) => handleBook(e)}>Book</button>
                                </td>
                            </tr>
                        )
                        )
                    }
                    <tr className='FilterRow'>
                        <td colSpan={3}>
                            <button type='button' id='sortBtn' onClick={() => handleSort()}>Sort by Price</button>
                        </td>
                        <td colSpan={3}>
                            <input type="range" id='rangeInput' min={200} max={400} onChange={(e) => handleChange(e)} list='markers' />
                            <datalist id="markers">
                                <option value="200" label="200"></option>
                                <option value="240" label="240"></option>
                                <option value="280" label="280"></option>
                                <option value="320" label="320"></option>
                                <option value="360" label="360"></option>
                                <option value="400" label="400"></option>
                            </datalist>
                            <button type='button' onClick={()=>(handleFilter())}>Filter</button>
                        </td>
                    </tr>
                </tbody>
            </table>

            </div>
        </div>
    )
}