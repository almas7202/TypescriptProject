import { useNavigate } from "react-router-dom"

export const Payment = () => {
    const nav = useNavigate()
    let time:Date = new Date()
    let x = setInterval(()=>{
        let now = new Date()
        let timer=(now.getSeconds()-time.getSeconds())
        let element:any = document.getElementById("a")
        element.innerHTML=String(timer)
        { timer > (Math.random()*30) ? DonePayment() : false}
        let divv:any = document.getElementById("h")
        timer=timer*6
        divv.style.backgroundImage="conic-gradient(from "+timer+"deg,black,white)"
    },1000)
    const DonePayment = ()=>{
        clearInterval(x)
        nav('/')
    }
    return (
        <>
            <h1>Wait For Payment Confirmation</h1>
            <div className="Timer" id="h" style={{backgroundImage:"conic-gradient(from 0deg,black,white)"}}></div>       
            <p id="a">0</p>
        </>
    )
}