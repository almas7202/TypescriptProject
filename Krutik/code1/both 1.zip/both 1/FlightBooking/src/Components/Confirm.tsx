import { useState } from "react";
import { Flight } from "../App";
import classData from '../Data/class.json'
import { useNavigate } from "react-router-dom";

interface ConfirmProps {
    BookedFlight: Flight,
}
interface BillObjectType {
    price: number,
    gst: number,
    total: number
}
export const Confirm = ({ BookedFlight }: ConfirmProps) => {
    const nav = useNavigate()
    const [Quantity, setQuantity] = useState<number>(1)
    const [Bill,setBill] = useState<BillObjectType>(
        {
            price: BookedFlight.price,
            gst: (BookedFlight.price * 0.18),
            total: BookedFlight.price * 0.18 + BookedFlight.price
        }
    )
    const handleQuantity = (e: any) => {
        const { value } = e.target
        setQuantity(value)
    }
    const handleClass = (e: any) => {
        const {value} = e.target
        setBill(
            {...Bill,
                price:(BookedFlight.price)*value,
                gst:(BookedFlight.price*0.18)*value,
                total:((BookedFlight.price*0.18)+BookedFlight.price)*value
            }
        )
    }
    return (
        <div>
            <form method="get">
                <label>First Name :</label>
                <input type="text" placeholder="Enter First Name" />
                <label>Middle Name :</label>
                <input type="text" placeholder="Enter Middle Name" />
                <label>Last Name :</label>
                <input type="text" placeholder="Enter Last Name" /><br />
                <label>Number of Seats :</label>
                <input type="number" min={1} defaultValue={1} max={9} onChange={(e) => handleQuantity(e)} placeholder="Enter Number of Seats" /><br />
                <label>Class :</label>
                {
                    classData.map((flightClass:any, index: number) => (
                        <div key={index}>
                            <input type="radio" name="class" value={flightClass.price} defaultChecked={flightClass.class=="Economy" ? true : false} onChange={(e)=>handleClass(e)}/>
                            <label>{flightClass.class}</label>
                        </div>
                    ))
                }
                <br />
                <label>Price :</label>
                <p>{Bill?.price * Quantity}</p>
                <label>GST(18%) :</label>
                <p>{Bill?.gst * Quantity}</p>
                <label>Total Price :</label>
                <p>{Bill?.total * Quantity}</p>
                <button type="button" onClick={()=>nav('/payment')}>Book Now</button>
            </form>
        </div>
    )
}